mysqlimport -u root cmdev C:/cmdev/data/in/dept.txt
