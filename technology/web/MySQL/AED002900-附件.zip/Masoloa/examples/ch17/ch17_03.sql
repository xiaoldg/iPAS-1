mysqlshow -u root 


mysqlshow -u root world


mysqlshow -u root world country
