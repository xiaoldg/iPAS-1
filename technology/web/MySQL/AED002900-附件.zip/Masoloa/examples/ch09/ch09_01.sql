SELECT * FROM world.city WHERE Name='Taipei'
