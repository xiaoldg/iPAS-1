Effective-Python-Penetration-Testing By Packt Publishing

This is the code repository for Effective Python Penetration Testing, published by Packt Publishing. It contains all the required files to run the code.

This book is ideal for those who are comfortable with Python or a similar language and need no help with basic programming concepts but want to understand the basics of penetration testing and the problems pentesters face.

Related Books

*Advanced Penetration Testing for Highly-Secured Environments: The Ultimate Security Guide

*Python Testing: Beginner's Guide

*Python Web Penetration Testing Cookbook