#!/usr/bin/python

msg = raw_input('Please enter the string to encode: ')

print "Your B64 encoded string is: " + msg.encode('base64')